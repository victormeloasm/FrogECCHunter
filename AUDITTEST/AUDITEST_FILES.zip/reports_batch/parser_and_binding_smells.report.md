# FrogECCHunter Report

- **Title:** Parser and transcript-binding smell bundle
- **Mode:** `ecdh\_oracle`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `10`
- **Recovered keys:** `0`

## Severity summary

- `critical`: 1
- `high`: 5
- `medium`: 4
- `low`: 0

## Category summary

- `ecdh`: 1
- `implementation`: 2
- `parser`: 3
- `protocol`: 3
- `rng`: 1

## Primary findings

### `device\_identifier\_seeded\_nonce`

- Fault: **Device-identifier seeded nonce generation**
- Category: `rng`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact rng.generator = device\_id
- impact = device identifiers are low-entropy, persistent inputs and must never drive ECC nonce generation

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `compressed\_point\_length\_relaxed`

- Fault: **Relaxed public-key length checks**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.relaxed\_pubkey\_length = true
- impact = relaxed length checks can let malformed public keys slip into deeper parsing code paths

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_hybrid\_pubkeys`

- Fault: **Hybrid SEC1 public key acceptance**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_hybrid\_pubkeys = true
- impact = hybrid SEC1 encodings are obsolete and accepting them widens the parser attack surface

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_noncanonical\_integers`

- Fault: **Non-canonical integer encoding acceptance**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_noncanonical\_integers = true
- impact = accepting non-canonical integers can produce ambiguous encodings and verifier disagreements

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `static\_ephemeral\_key\_usage`

- Fault: **Static ephemeral ECDH key usage**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.static\_ephemeral = true
- impact = reusing an ephemeral ECDH key turns a supposedly fresh exchange into a replayable long-lived secret

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `transcript\_binding\_absent`

- Fault: **Transcript binding absent**
- Category: `protocol`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact protocol.transcript\_binding = false
- impact = without transcript binding, signatures and key agreement outputs can be replayed or transplanted across sessions

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `complete\_formula\_absent`

- Fault: **Complete group formulas absent**
- Category: `implementation`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact implementation.complete\_group\_formulas = false
- impact = incomplete formulas increase the risk of exceptional-case side channels and input-dependent behavior

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `missing\_domain\_separation\_in\_hashing`

- Fault: **Missing domain separation in hashing**
- Category: `protocol`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact protocol.domain\_separation = false
- impact = reusing the same hash flow across roles without domain separation invites cross-protocol confusion

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `scalar\_blinding\_absent`

- Fault: **Scalar blinding absent**
- Category: `implementation`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact implementation.scalar\_blinding = false
- impact = lack of scalar blinding weakens resistance against timing and power leakage

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `signature\_context\_reuse`

- Fault: **Signature context reuse across domains**
- Category: `protocol`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact protocol.signature\_context\_reuse = true
- impact = reusing the same signature context across protocol roles undermines domain separation

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

