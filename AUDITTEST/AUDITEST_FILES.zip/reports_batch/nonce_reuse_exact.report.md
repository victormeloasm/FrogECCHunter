# FrogECCHunter Report

- **Title:** Exact ECDSA nonce reuse
- **Mode:** `ecdsa`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `8`
- **Recovered keys:** `1`

## Severity summary

- `critical`: 5
- `high`: 1
- `medium`: 2
- `low`: 0

## Category summary

- `ecdsa`: 3
- `protocol`: 1
- `rng`: 4

## Primary findings

### `exact\_nonce\_reuse`

- Fault: **Exact ECDSA nonce reuse**
- Category: `ecdsa`
- Severity: `critical`
- Recoverability: `R5\_trivial\_or\_lab\_proven`
- Recovered key: `FLAG{514631507721405306660750627004050553169894890361520731142054384109816726305}`

Evidence

- signature\_pair = 0,1
- recovered\_nonce = 1375488932362216742658885
- recovered\_private\_key\_decimal = 514631507721405306660750627004050553169894890361520731142054384109816726305
- flag = FLAG{514631507721405306660750627004050553169894890361520731142054384109816726305}
- impact = a single reused ECDSA nonce exposes the long-term signing key

Remediation

- rotate to deterministic RFC6979-style nonces immediately and retire affected signing keys
- search historical signatures for repeated or structured r values and reissue signatures after key rotation

### `nonce\_source\_rand`

- Fault: **rand()-based nonce generation**
- Category: `rng`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact rng.source = rand
- impact = rand()-class generators are not suitable for cryptographic nonce generation

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `nonce\_source\_time\_seeded`

- Fault: **Time-seeded nonce generation**
- Category: `rng`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact rng.seed = time
- impact = time-seeded RNG state is frequently guessable and can lead directly to nonce recovery

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `repeated\_r\_values`

- Fault: **Repeated ECDSA r values**
- Category: `ecdsa`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = r value D34D50BFCF4971A85DC72D6E3F1F672F6FE2BA1F86CC4956D7C1175E62A33812 appears 2 times
- impact = repeated r values are a classic marker for nonce reuse or sign-flipped nonces

Remediation

- rotate to deterministic RFC6979-style nonces immediately and retire affected signing keys
- search historical signatures for repeated or structured r values and reissue signatures after key rotation

### `rng\_state\_reuse\_after\_fork`

- Fault: **RNG state reuse after fork**
- Category: `rng`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact rng.state\_reuse\_after\_fork = true
- impact = forked processes that reuse RNG state frequently repeat nonces or scalars

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `nonce\_not\_rfc6979`

- Fault: **Nonce generation not tied to RFC6979 or equivalent deterministic DRBG**
- Category: `rng`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact nonce.rfc6979 = false
- impact = deterministic nonces anchored in a strong construction reduce a large class of RNG failures

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `high\_s\_malleability\_acceptance`

- Fault: **High-S malleability acceptance**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = 1 supplied signature(s) use high-S form
- impact = accepting high-S values preserves malleability classes unless the protocol normalizes them

Remediation

- normalize signatures to low-S form at signing and verification boundaries
- add replay and duplicate-signature tests to confirm malleability is closed

### `missing\_domain\_separation\_in\_hashing`

- Fault: **Missing domain separation in hashing**
- Category: `protocol`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact protocol.domain\_separation = false
- impact = reusing the same hash flow across roles without domain separation invites cross-protocol confusion

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

