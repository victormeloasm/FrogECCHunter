# FrogECCHunter Report

- **Title:** v22 SPKI and backend differential suite
- **Mode:** `parser`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `12`
- **Recovered keys:** `0`

## Severity summary

- `critical`: 0
- `high`: 4
- `medium`: 8
- `low`: 0

## Category summary

- `backend`: 4
- `curve`: 3
- `parser`: 5

## Primary findings

### `backend\_explicit\_curve\_parameter\_differential`

- Fault: **Explicit-curve-parameter handling differs across backends**
- Category: `backend`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact backend.diff.explicit\_curve\_parameters = true
- impact = explicit-parameter handling must be pinned across backends or one path may accept hostile domains

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `backend\_spki\_vs\_sec1\_differential`

- Fault: **SPKI-vs-SEC1 interpretation differs across backends**
- Category: `backend`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact backend.diff.spki\_vs\_sec1 = true
- impact = backend disagreement between SPKI and raw SEC1 decoding creates dangerous portability gaps

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `curve\_explicit\_parameter\_proof\_missing`

- Fault: **Explicit curve parameters lack proof bundle**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.explicit\_parameter\_proof\_documented = false
- impact = explicit curve parameters need a proof bundle and rationale so auditors can validate the domain

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `parser\_accepts\_spki\_without\_named\_curve`

- Fault: **Parser accepts SPKI without a named-curve OID**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_spki\_without\_named\_curve = true
- impact = SPKI objects without a named-curve OID should not be accepted ambiguously

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `backend\_oid\_resolution\_differential`

- Fault: **OID resolution differs across backends**
- Category: `backend`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact backend.diff.oid\_resolution = true
- impact = curve-OID resolution must be pinned so one backend cannot reinterpret another backend's input

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `backend\_pem\_label\_differential`

- Fault: **PEM-label handling differs across backends**
- Category: `backend`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact backend.diff.pem\_label = true
- impact = PEM label handling should be deterministic across backends to avoid object confusion

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `curve\_alias\_registry\_mismatch`

- Fault: **Curve alias registry mismatch**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.alias\_registry\_consistent = false
- impact = curve aliases must resolve deterministically or allowlists and reports become ambiguous

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_spki\_oid\_missing`

- Fault: **Curve SPKI OID missing from documentation**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.spki\_oid\_documented = false
- impact = serious reviews should record the SPKI/OID identity that callers are expected to consume

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `parser\_accepts\_multiple\_pem\_objects`

- Fault: **Parser accepts multiple PEM objects without isolation**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_multiple\_pem\_objects = true
- impact = accepting multiple PEM objects in one blob can produce parser differentials and silent object substitution

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_raw\_ec\_point\_without\_spki`

- Fault: **Parser accepts raw EC points where SPKI is required**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_raw\_ec\_point\_without\_spki = true
- impact = accepting naked EC points where SPKI is required weakens object typing and policy control

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_spki\_bitstring\_padding`

- Fault: **Parser accepts padded SPKI BIT STRING keys**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_spki\_bitstring\_padding = true
- impact = padded SPKI BIT STRING keys widen parser differential and canonicalization risk

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_unknown\_pem\_label`

- Fault: **Parser accepts unknown PEM labels**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_unknown\_pem\_label = true
- impact = unknown PEM labels can hide unexpected object types from callers

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

