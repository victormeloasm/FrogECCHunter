# FrogECCHunter Report

- **Title:** v20 structural suite across ECDSA, ECDH, parser, oracle, and provenance
- **Mode:** `ecdh\_oracle`
- **Curve:** `prime256v1`
- **Checks:** `348`
- **Findings:** `111`
- **Recovered keys:** `0`

## Severity summary

- `critical`: 15
- `high`: 53
- `medium`: 40
- `low`: 3

## Category summary

- `curve`: 23
- `ecdh`: 22
- `ecdsa`: 20
- `oracle`: 13
- `parser`: 21
- `protocol`: 1
- `validation`: 5
- `verification`: 6

## Primary findings

### `all\_zero\_shared\_secret\_acceptance`

- Fault: **All-zero shared secret acceptance**
- Category: `ecdh`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.accept\_all\_zero\_shared\_secret = true
- impact = accepting an all-zero shared secret can turn invalid-peer inputs into protocol confusion and key-confirmation bypasses

Remediation

- reject all-zero shared secrets before KDF or key confirmation
- add malicious-peer regression vectors that force invalid and low-order peer inputs

### `ecdsa\_cross\_curve\_signature\_acceptance`

- Fault: **ECDSA cross-curve signature acceptance**
- Category: `verification`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.accept\_cross\_curve\_signature = true
- impact = accepting signatures under the wrong curve collapses domain separation

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `ecdsa\_signer\_accepts\_external\_nonce`

- Fault: **ECDSA signer accepts external nonce input**
- Category: `ecdsa`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdsa.accept\_external\_nonce = true
- impact = allowing callers to inject k directly is a common route to catastrophic nonce misuse

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `ecdsa\_signer\_allows\_zero\_nonce`

- Fault: **ECDSA signer allows zero nonce**
- Category: `ecdsa`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdsa.allow\_zero\_nonce = true
- impact = a zero or invalid nonce destroys ECDSA correctness and can leak private material

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `invalid\_curve\_classification\_oracle`

- Fault: **Invalid-curve classification oracle exposure**
- Category: `oracle`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.invalid\_curve\_classification = true
- impact = distinguishing invalid-curve failures from other failures gives attackers feedback for point crafting

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `low\_order\_peer\_point\_acceptance`

- Fault: **Low-order peer point acceptance**
- Category: `ecdh`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.accept\_low\_order\_points = true
- impact = accepting low-order peer points can collapse the ECDH shared-secret space and leak scalar information

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `mixed\_curve\_ecdh\_acceptance`

- Fault: **Mixed-curve ECDH acceptance**
- Category: `ecdh`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.accept\_mixed\_curve\_peer\_keys = true
- impact = accepting peer keys from the wrong curve breaks the meaning of the shared secret and can enable confinement attacks

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `oracle\_low\_order\_classification\_leak`

- Fault: **Low-order classification oracle exposure**
- Category: `oracle`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.low\_order\_classification\_leak = true
- impact = classifying low-order points directly feeds subgroup-confinement workflows

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `parser\_accepts\_coordinate\_overflow`

- Fault: **Parser accepts coordinate overflow**
- Category: `parser`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_coordinate\_overflow = true
- impact = coordinates outside the field must never be accepted or silently reduced

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_scalar\_overflow\_reduction`

- Fault: **Parser reduces out-of-range scalars silently**
- Category: `parser`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.reduce\_scalar\_overflow = true
- impact = silent scalar reduction masks malformed inputs and destroys canonical validation

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `subgroup\_check\_missing`

- Fault: **Missing subgroup membership check**
- Category: `validation`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.subgroup\_check = false
- impact = missing subgroup checks enable confinement attacks and invalid-point workflows

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `subgroup\_classification\_oracle`

- Fault: **Subgroup classification oracle exposure**
- Category: `oracle`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.subgroup\_classification = true
- impact = telling the caller whether a point failed subgroup checks gives attackers a confinement oracle

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `twist\_classification\_oracle`

- Fault: **Twist classification oracle exposure**
- Category: `oracle`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.twist\_classification = true
- impact = classifying twist failures separately can hand attackers a guided path toward hostile low-order inputs

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `twist\_point\_acceptance`

- Fault: **Twist point acceptance**
- Category: `validation`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.accept\_twist\_points = true
- impact = twist acceptance can hand attackers low-order structure outside the main curve

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `verifier\_accepts\_negative\_signature\_scalars`

- Fault: **Verifier accepts negative signature scalars**
- Category: `verification`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.accept\_negative\_signature\_scalars = true
- impact = negative scalar acceptance in DER or textual parsers can reintroduce alternate hostile encodings

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `all\_zero\_shared\_secret\_oracle`

- Fault: **All-zero shared-secret oracle exposure**
- Category: `oracle`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.all\_zero\_shared\_secret = true
- impact = revealing whether a shared secret collapsed to zero can drive adaptive malicious-peer workflows

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `batch\_verifier\_missing\_per\_signature\_binding`

- Fault: **Batch verifier missing per-signature binding**
- Category: `verification`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.per\_signature\_binding = false
- impact = batch verification must bind each signature independently to avoid transcript mixups

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `cofactor\_clearing\_missing`

- Fault: **Missing cofactor clearing**
- Category: `validation`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.cofactor\_clearing = false
- impact = missing cofactor clearing leaves implementations exposed on curves and protocols where cofactors matter

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `cofactor\_not\_reflected\_in\_protocol`

- Fault: **Protocol ignores non-trivial cofactor handling**
- Category: `protocol`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact protocol.cofactor\_handling = false
- impact = protocols on non-trivial-cofactor curves need explicit cofactor handling to avoid subgroup surprises

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `contributory\_ecdh\_absent`

- Fault: **Contributory ECDH check absent**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact protocol.contributory\_ecdh = false
- impact = without contributory ECDH checks, attacker-chosen inputs can collapse the shared-secret space

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `curve\_anomalous\_check\_missing`

- Fault: **Anomalous-curve check missing**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.anomalous\_checked = false
- impact = anomalous curves must be ruled out explicitly in a serious ECC audit

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_complete\_parameter\_set\_missing`

- Fault: **Complete parameter set missing**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.complete\_parameter\_set\_documented = false
- impact = auditors need the full parameter set, not only a curve name or fragment

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_order\_factorization\_unchecked`

- Fault: **Curve order factorization unchecked**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.order\_factorization\_checked = false
- impact = partial factorization checks help surface dangerous small factors in the full group order

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_order\_proof\_missing`

- Fault: **Curve order proof missing**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.order\_proof\_documented = false
- impact = without an order proof, auditors cannot trust the claimed subgroup size or resulting security level

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_quadratic\_twist\_cofactor\_unchecked`

- Fault: **Quadratic twist cofactor unchecked**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.twist\_cofactor\_checked = false
- impact = twist cofactors matter when reviewing invalid-point resistance

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `curve\_small\_factor\_scan\_missing`

- Fault: **Curve small-factor scan missing**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.small\_factor\_scan\_done = false
- impact = small-factor scans are low-cost and high-value for custom-curve sanity

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_supersingularity\_check\_missing`

- Fault: **Supersingularity check missing**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.supersingularity\_checked = false
- impact = supersingularity status should be explicit so security assumptions remain clear

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_twist\_factorization\_unchecked`

- Fault: **Twist order factorization unchecked**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.twist\_factorization\_checked = false
- impact = twist factorization is central to invalid-point and low-order risk review

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `ecdh\_channel\_binding\_missing`

- Fault: **ECDH channel binding missing**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.channel\_binding = false
- impact = channel binding ties the derived key to the intended authenticated context

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_ephemeral\_reuse\_detection\_missing`

- Fault: **ECDH ephemeral reuse detection missing**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.ephemeral\_reuse\_detection = false
- impact = reused ephemeral keys break unlinkability and can magnify compromise windows

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_kdf\_transcript\_binding\_missing`

- Fault: **ECDH KDF lacks transcript binding**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.kdf\_transcript\_binding = false
- impact = binding the ECDH transcript into the KDF is required to stop transcript transplantation and unknown-key-share confusion

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_peer\_identity\_unbound`

- Fault: **ECDH peer identity not bound into key schedule**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.peer\_identity\_binding = false
- impact = without binding peer identity into the key schedule, authenticated channel semantics can silently drift

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_public\_key\_validation\_order\_wrong`

- Fault: **ECDH validation order incorrect**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.validation\_before\_scalar\_mul = false
- impact = peer keys must be validated before scalar multiplication or attacker-controlled points can slip deeper

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_rejects\_infinity\_late`

- Fault: **ECDH rejects infinity too late**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.reject\_infinity\_pre\_kdf = false
- impact = the point at infinity must be rejected before any downstream secret handling

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_secret\_export\_without\_context`

- Fault: **ECDH secret export without context**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.secret\_export\_context = false
- impact = exported shared secrets need context labels so downstream consumers cannot confuse them

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_unknown\_key\_share\_risk`

- Fault: **Unknown key-share risk in ECDH flow**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.unknown\_key\_share\_protection = false
- impact = UKS protection is needed so both sides agree on who contributed to the established key

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdsa\_context\_domain\_separation\_missing`

- Fault: **ECDSA signing context lacks domain separation**
- Category: `ecdsa`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdsa.domain\_separation = false
- impact = ECDSA contexts reused across protocol domains invite transcript confusion and nonce cross-contamination

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_hash\_algorithm\_unpinned`

- Fault: **ECDSA hash algorithm unpinned**
- Category: `ecdsa`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdsa.hash\_algorithm\_pinned = false
- impact = unpinned hash selection can create verification drift and downgrade surprises

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_nonce\_reuse\_alarm\_missing`

- Fault: **ECDSA nonce reuse alarm missing**
- Category: `ecdsa`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdsa.nonce\_reuse\_alarm = false
- impact = signers should alarm and halt when repeated nonce indicators appear

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `ecdsa\_signature\_encoding\_canonicalization\_missing`

- Fault: **ECDSA signature canonicalization missing**
- Category: `ecdsa`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdsa.signature\_canonicalization = false
- impact = canonical signature encoding prevents duplicate encodings of the same mathematical signature

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_signer\_allows\_nonce\_equal\_order`

- Fault: **ECDSA signer allows nonce equal to group order**
- Category: `ecdsa`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdsa.allow\_nonce\_equal\_order = true
- impact = nonces must be reduced and checked strictly inside the valid scalar range

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `ecdsa\_signer\_key\_commitment\_missing`

- Fault: **ECDSA signer key commitment missing**
- Category: `ecdsa`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdsa.key\_commitment = false
- impact = binding the expected signing key identity into higher-level protocol state prevents cross-key confusion

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_signer\_role\_binding\_missing`

- Fault: **ECDSA signer role binding missing**
- Category: `ecdsa`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdsa.role\_binding = false
- impact = signing roles should be bound so the same key is not silently reused across incompatible protocol directions

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_signer\_state\_rollback\_detection\_missing`

- Fault: **ECDSA signer state rollback detection missing**
- Category: `ecdsa`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdsa.rollback\_detection = false
- impact = rollback detection helps catch VM snapshots or device restores that replay nonce state

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_verifier\_accepts\_hash\_length\_mismatch`

- Fault: **ECDSA verifier accepts hash-length mismatch**
- Category: `verification`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.accept\_hash\_length\_mismatch = true
- impact = mismatched digest lengths can create cross-implementation verification drift

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `oracle\_batch\_membership\_leak`

- Fault: **Batch-membership oracle exposure**
- Category: `oracle`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.batch\_membership\_leak = true
- impact = revealing which batch element failed gives attackers a guided verifier oracle

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `oracle\_scalar\_range\_leak`

- Fault: **Scalar range oracle exposure**
- Category: `oracle`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.scalar\_range\_leak = true
- impact = telling callers whether a scalar failed a range check gives adaptive feedback

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `oracle\_transcript\_binding\_leak`

- Fault: **Transcript-binding oracle exposure**
- Category: `oracle`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.transcript\_binding\_leak = true
- impact = detailed transcript-binding failures create a protocol-structure oracle

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `parser\_accepts\_ber\_where\_der\_required`

- Fault: **Parser accepts BER where DER required**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_ber\_where\_der\_required = true
- impact = BER acceptance in DER-only contexts widens canonicalization drift

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_duplicate\_der\_fields`

- Fault: **Parser accepts duplicate DER fields**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_duplicate\_der\_fields = true
- impact = duplicate DER fields create ambiguity about which value downstream logic actually used

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_field\_length\_mismatch`

- Fault: **Parser accepts field-length mismatch**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_field\_length\_mismatch = true
- impact = field-length mismatches can hide truncated or padded hostile values from downstream checks

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_indefinite\_length\_der`

- Fault: **Parser accepts indefinite-length DER**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_indefinite\_length\_der = true
- impact = DER requires definite lengths; indefinite-length acceptance widens BER-style ambiguity

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_length\_prefix\_mismatch`

- Fault: **Parser accepts length-prefix mismatch**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_length\_prefix\_mismatch = true
- impact = declared and actual length mismatches should fail before any deeper processing

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_mixed\_spki\_and\_sec1`

- Fault: **Parser accepts mixed SPKI and SEC1 envelopes**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_mixed\_spki\_and\_sec1 = true
- impact = mixed envelope handling increases object-confusion risk

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_negative\_integers`

- Fault: **Parser accepts negative INTEGER encodings**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_negative\_integers = true
- impact = negative INTEGER acceptance can create alternate encodings for hostile scalar values

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_oid\_mismatch`

- Fault: **Parser accepts OID/domain mismatch**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_oid\_mismatch = true
- impact = accepting an OID that does not match the supplied domain parameters can produce dangerous parser differentials

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_sec1\_prefix\_confusion`

- Fault: **Parser accepts SEC1 prefix confusion**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_sec1\_prefix\_confusion = true
- impact = ambiguous SEC1 prefixes can let malformed compressed or hybrid points bypass format policy

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_truncated\_bitstring`

- Fault: **Parser accepts truncated BIT STRING**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.accept\_truncated\_bitstring = true
- impact = truncated bit strings can hide malformed keys behind forgiving decoders

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_error\_oracle`

- Fault: **Parser error oracle exposure**
- Category: `oracle`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.parser\_error\_classes = true
- impact = different parser errors can leak which validation layer failed and guide adaptive hostile inputs

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `peer\_key\_revalidation\_after\_parse\_missing`

- Fault: **Peer key not revalidated after parsing**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.revalidate\_after\_parse = false
- impact = decoded peer keys should be revalidated before scalar multiplication because parser acceptance alone is not enough

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `peer\_key\_type\_confusion`

- Fault: **Peer key type confusion in ECDH path**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.peer\_key\_type\_confusion = true
- impact = confusing Montgomery, Edwards, or Weierstrass peer-key encodings can route hostile inputs around validation

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `subgroup\_generator\_binding\_missing`

- Fault: **Subgroup/generator binding proof missing**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.subgroup\_generator\_binding\_documented = false
- impact = auditors need an explicit statement that the published generator really spans the claimed subgroup

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `subgroup\_order\_unchecked`

- Fault: **Subgroup order not validated**
- Category: `validation`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.subgroup\_order\_checked = false
- impact = unchecked subgroup order metadata undermines subgroup confinement assumptions

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `twist\_order\_unchecked`

- Fault: **Twist order unchecked**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.twist\_order\_checked = false
- impact = unchecked twist order leaves auditors blind to dangerous low-order structure outside the main curve

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `twist\_security\_unchecked`

- Fault: **Twist security not explicitly checked**
- Category: `validation`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.twist\_security\_checked = false
- impact = explicit twist-security validation helps catch dangerous low-order acceptance paths

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `verification\_error\_oracle`

- Fault: **Verification error oracle exposure**
- Category: `oracle`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.verification\_error\_classes = true
- impact = detailed verification failures can become a signature-validation oracle

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `verifier\_accepts\_duplicate\_signature\_encodings`

- Fault: **Verifier accepts duplicate signature encodings**
- Category: `verification`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.accept\_duplicate\_signature\_encodings = true
- impact = duplicate encodings widen parser differentials and complicate signing policy

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `verifier\_accepts\_overlong\_signature\_integers`

- Fault: **Verifier accepts overlong signature INTEGER values**
- Category: `verification`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.accept\_overlong\_signature\_integers = true
- impact = overlong INTEGER acceptance is a classic ASN.1 canonicalization failure

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `cofactor\_provenance\_missing`

- Fault: **Cofactor provenance missing**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.cofactor\_documented = false
- impact = cofactor values must be documented because protocol handling depends on them

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_cofactor\_decomposition\_missing`

- Fault: **Cofactor decomposition missing**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.cofactor\_decomposition\_documented = false
- impact = cofactor decomposition helps explain how subgroup structure is handled

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_embedding\_degree\_unchecked`

- Fault: **Embedding degree unchecked**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.embedding\_degree\_checked = false
- impact = embedding-degree review helps screen for MOV-style surprises

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_frey\_ruck\_unchecked`

- Fault: **Frey-Ruck bound unchecked**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.frey\_ruck\_checked = false
- impact = pairing-related sanity checks matter for nonstandard custom curves

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_mov\_bound\_unchecked`

- Fault: **MOV bound unchecked**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.mov\_bound\_checked = false
- impact = MOV-style transfer bounds are part of a serious custom-curve audit

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_parameter\_generation\_process\_missing`

- Fault: **Curve generation process missing**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.generation\_process\_documented = false
- impact = a parameter-generation narrative is essential for serious third-party review

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_prime\_generation\_proof\_missing`

- Fault: **Prime generation proof missing**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.prime\_generation\_proof\_documented = false
- impact = prime-generation provenance helps auditors trust the published base field

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_security\_level\_undocumented`

- Fault: **Curve security level undocumented**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.security\_level\_documented = false
- impact = published security targets help reviewers judge whether a curve is fit for purpose

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_seed\_provenance\_missing`

- Fault: **Curve seed provenance missing**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.seed\_provenance\_documented = false
- impact = missing parameter provenance makes hostile or accidentally weak custom curves harder to audit

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `custom\_curve\_security\_rationale\_missing`

- Fault: **Custom curve security rationale missing**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.security\_rationale\_documented = false
- impact = custom curves need a written security rationale so parameter choices are auditable

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdh\_cofactor\_mode\_undocumented`

- Fault: **ECDH cofactor mode undocumented**
- Category: `ecdh`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdh.cofactor\_mode\_documented = false
- impact = auditors need to know whether plain, cofactor, or Decaf-style handling is in use

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_kdf\_context\_missing`

- Fault: **ECDH KDF lacks context separation**
- Category: `ecdh`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdh.kdf\_context\_binding = false
- impact = a context-free KDF output is easier to reuse across roles and protocols than intended

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_key\_confirmation\_optional\_by\_default`

- Fault: **ECDH key confirmation optional by default**
- Category: `ecdh`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdh.key\_confirmation\_default\_on = false
- impact = opting out of key confirmation by default increases silent failure risk

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_no\_explicit\_role\_separation`

- Fault: **ECDH explicit role separation missing**
- Category: `ecdh`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdh.role\_separation = false
- impact = key schedules should distinguish initiator and responder contributions

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_peer\_curve\_identifier\_unbound`

- Fault: **ECDH peer curve identifier unbound**
- Category: `ecdh`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdh.peer\_curve\_identifier\_bound = false
- impact = curve identifiers should be bound so mixed-family inputs cannot drift across adapters

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_peer\_fingerprint\_unchecked`

- Fault: **ECDH peer fingerprint unchecked**
- Category: `ecdh`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdh.peer\_fingerprint\_checked = false
- impact = out-of-band peer fingerprint checks are essential in pinned-key deployments

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_session\_id\_unbound`

- Fault: **ECDH session identifier unbound**
- Category: `ecdh`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdh.session\_id\_bound = false
- impact = binding a session identifier reduces replay and transcript-splicing risk

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdh\_shared\_secret\_reflection\_risk`

- Fault: **ECDH shared secret reflection risk**
- Category: `ecdh`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdh.reflection\_protection = false
- impact = reflection protection helps stop a peer from feeding your own keying material back to you

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `ecdsa\_context\_string\_missing`

- Fault: **ECDSA context string missing**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdsa.context\_string\_bound = false
- impact = binding a context string into the signing domain reduces cross-protocol confusion

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_low\_s\_policy\_missing`

- Fault: **ECDSA low-S enforcement missing**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdsa.low\_s\_enforced = false
- impact = without low-S normalization or rejection, signatures remain malleable and harder to canonicalize

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_message\_prefix\_policy\_missing`

- Fault: **ECDSA message prefix policy missing**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdsa.message\_prefix\_policy = false
- impact = domain prefixes help stop signing the same raw bytes in multiple semantic contexts

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_nonce\_fault\_countermeasures\_absent`

- Fault: **ECDSA nonce fault countermeasures absent**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdsa.nonce\_fault\_countermeasures = false
- impact = nonce-fault countermeasures help catch glitched or repeated k generation before signatures leave the signer

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `ecdsa\_nonce\_monobit\_health\_test\_missing`

- Fault: **ECDSA nonce health tests missing**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdsa.nonce\_health\_tests = false
- impact = lightweight health tests catch catastrophic RNG collapse before signatures ship

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `ecdsa\_nonce\_recovery\_on\_duplicate\_r\_unchecked`

- Fault: **Duplicate-r response plan missing**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdsa.duplicate\_r\_response = false
- impact = implementations should quarantine keys and investigate when repeated r values are detected

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `ecdsa\_nonce\_retry\_on\_zero\_missing`

- Fault: **ECDSA zero-nonce retry missing**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdsa.retry\_on\_zero\_nonce = false
- impact = signers should retry or fail closed when k lands on an invalid scalar

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `ecdsa\_prehash\_identifier\_unbound`

- Fault: **ECDSA prehash identifier unbound**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdsa.prehash\_identifier\_bound = false
- impact = the signing transcript should bind which hash function and prehash mode were used

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_signature\_length\_policy\_missing`

- Fault: **ECDSA signature length policy missing**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdsa.signature\_length\_policy = false
- impact = explicit signature-length policy avoids acceptance drift across transports and parsers

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `ecdsa\_signer\_allows\_raw\_message\_without\_prehash\_policy`

- Fault: **ECDSA raw-message policy missing**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact ecdsa.raw\_message\_policy = false
- impact = signers should document whether they sign raw messages, prehashes, or both

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `generator\_provenance\_missing`

- Fault: **Generator provenance missing**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.generator\_provenance\_documented = false
- impact = missing generator provenance makes it harder to rule out hostile or accidental generator choices

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `oracle\_cofactor\_mode\_leak`

- Fault: **Cofactor-mode oracle exposure**
- Category: `oracle`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact oracle.cofactor\_mode\_leak = true
- impact = revealing cofactor-handling mode makes it easier to tailor hostile peer points

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `oracle\_curve\_identifier\_leak`

- Fault: **Curve identifier oracle exposure**
- Category: `oracle`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact oracle.curve\_identifier\_leak = true
- impact = revealing the exact curve family can help attackers tailor malformed inputs

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `oracle\_seed\_source\_leak`

- Fault: **Seed-source oracle exposure**
- Category: `oracle`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact oracle.seed\_source\_leak = true
- impact = leaking whether time, PID, or device IDs influenced state helps offline enumeration

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `parser\_accepts\_duplicate\_pubkey\_forms`

- Fault: **Parser accepts duplicated public-key forms**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_duplicate\_pubkey\_forms = true
- impact = accepting multiple textual or binary forms for the same public key widens canonicalization attack surface

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_empty\_integers`

- Fault: **Parser accepts empty INTEGER values**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_empty\_integers = true
- impact = empty integer acceptance can create alternate encodings for zero and other edge values

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_invalid\_asn1\_tag\_class`

- Fault: **Parser accepts invalid ASN.1 tag class**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_invalid\_asn1\_tag\_class = true
- impact = unexpected tag classes should fail closed in strict ECC object parsers

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_leading\_zero\_scalars`

- Fault: **Parser accepts leading-zero scalars**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_leading\_zero\_scalars = true
- impact = leading-zero scalar acceptance can create ambiguous encodings and parser differentials

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_multiple\_pem\_objects`

- Fault: **Parser accepts multiple PEM objects without isolation**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_multiple\_pem\_objects = true
- impact = accepting multiple PEM objects in one blob can produce parser differentials and silent object substitution

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_overlong\_length\_encodings`

- Fault: **Parser accepts overlong length encodings**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_overlong\_length\_encodings = true
- impact = overlong ASN.1 lengths are a classic canonicalization failure

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_uncompressed\_when\_policy\_requires\_compressed`

- Fault: **Parser ignores compressed-point policy**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.require\_compressed\_points = false
- impact = ignoring an agreed compressed-point policy weakens canonicalization and can bypass allowlists

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `trace\_of\_frobenius\_unchecked`

- Fault: **Trace of Frobenius not checked**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.trace\_checked = false
- impact = trace sanity checks help catch malformed or dangerously misunderstood custom-curve instances

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_documentation\_hash\_missing`

- Fault: **Curve documentation hash missing**
- Category: `curve`
- Severity: `low`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.documentation\_hash\_recorded = false
- impact = recording documentation hashes helps reviewers pin exactly what was audited

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `parser\_accepts\_mixed\_case\_hex\_scalars`

- Fault: **Parser accepts mixed-case scalar text without canonicalization**
- Category: `parser`
- Severity: `low`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_mixed\_case\_hex\_scalars = true
- impact = mixed textual forms widen canonicalization drift and can mask duplicate inputs

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `parser\_accepts\_odd\_length\_hex\_without\_normalization`

- Fault: **Parser accepts odd-length hex without normalization policy**
- Category: `parser`
- Severity: `low`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_odd\_length\_hex\_without\_normalization = true
- impact = odd-length hex parsing should be explicit to avoid hidden nibble shifts

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

