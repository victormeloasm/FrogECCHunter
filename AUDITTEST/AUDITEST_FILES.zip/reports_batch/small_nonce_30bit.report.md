# FrogECCHunter Report

- **Title:** Untitled challenge
- **Mode:** `ecdsa`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `1`
- **Recovered keys:** `1`

## Severity summary

- `critical`: 1
- `high`: 0
- `medium`: 0
- `low`: 0

## Category summary

- `ecdsa`: 1

## Primary findings

### `small\_nonce\_bsgs`

- Fault: **Small ECDSA nonce**
- Category: `ecdsa`
- Severity: `critical`
- Recoverability: `R5\_trivial\_or\_lab\_proven`
- Recovered key: `FLAG{16157387885063800092468972531095442600227637936690303362357377535130907802014}`

Evidence

- signature\_index = 0
- bound\_bits = 30
- recovered\_nonce = 987654321
- recovered\_private\_key\_decimal = 16157387885063800092468972531095442600227637936690303362357377535130907802014
- flag = FLAG{16157387885063800092468972531095442600227637936690303362357377535130907802014}
- impact = a bounded nonce search over even 30 bits is fatal to ECDSA secrecy

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

