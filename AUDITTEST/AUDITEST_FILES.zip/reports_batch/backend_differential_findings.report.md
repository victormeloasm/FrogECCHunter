# FrogECCHunter Report

- **Title:** Backend differential and curve provenance findings
- **Mode:** `parser`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `21`
- **Recovered keys:** `0`

## Severity summary

- `critical`: 2
- `high`: 11
- `medium`: 8
- `low`: 0

## Category summary

- `backend`: 9
- `curve`: 12

## Primary findings

### `backend\_invalid\_curve\_rejection\_differential`

- Fault: **Invalid-curve rejection differs across backends**
- Category: `backend`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact backend.diff.invalid\_curve\_rejection = true
- impact = different invalid-curve behavior makes it easier to route hostile points toward the weakest backend

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points
- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `backend\_pubkey\_validation\_differential`

- Fault: **Public-key validation differs across backends**
- Category: `backend`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact backend.diff.pubkey\_validation = true
- impact = if backends disagree on public-key validation, hostile keys can slip through one adapter while others reject them

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `backend\_der\_strictness\_differential`

- Fault: **DER strictness differs across backends**
- Category: `backend`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact backend.diff.der\_strictness = true
- impact = DER strictness differentials create parser confusion and portability bugs with security impact

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `backend\_explicit\_parameter\_policy\_differential`

- Fault: **Explicit-parameter policy differs across backends**
- Category: `backend`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact backend.diff.explicit\_parameter\_policy = true
- impact = explicit-parameter policy must be consistent or hostile objects may route differently across environments

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `backend\_low\_s\_policy\_differential`

- Fault: **Low-S policy differs across backends**
- Category: `backend`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact backend.diff.low\_s\_policy = true
- impact = different low-S policies produce verifier disagreement and duplicate-signature ambiguity

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `backend\_point\_parser\_differential`

- Fault: **Point parser behavior differs across backends**
- Category: `backend`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact backend.diff.point\_parser = true
- impact = point-decoding disagreement can split validation outcomes and invalidate audit assumptions

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs
- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `backend\_scalar\_range\_policy\_differential`

- Fault: **Scalar-range policy differs across backends**
- Category: `backend`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact backend.diff.scalar\_range\_policy = true
- impact = scalar-range disagreement can make malformed keys or signatures valid in only part of the estate

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `backend\_signature\_canonicalization\_differential`

- Fault: **Signature canonicalization differs across backends**
- Category: `backend`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact backend.diff.signature\_canonicalization = true
- impact = signature canonicalization differences widen replay and parser-confusion surfaces

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `curve\_anomalous\_check\_missing`

- Fault: **Anomalous-curve check missing**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.anomalous\_checked = false
- impact = anomalous curves must be ruled out explicitly in a serious ECC audit

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_order\_factorization\_unchecked`

- Fault: **Curve order factorization unchecked**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.order\_factorization\_checked = false
- impact = partial factorization checks help surface dangerous small factors in the full group order

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_supersingularity\_check\_missing`

- Fault: **Supersingularity check missing**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.supersingularity\_checked = false
- impact = supersingularity status should be explicit so security assumptions remain clear

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_twist\_factorization\_unchecked`

- Fault: **Twist order factorization unchecked**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.twist\_factorization\_checked = false
- impact = twist factorization is central to invalid-point and low-order risk review

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `curve\_twist\_security\_margin\_undocumented`

- Fault: **Twist security margin undocumented**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.twist\_security\_margin\_documented = false
- impact = twist security needs an explicit margin statement when hostile points are in scope

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `backend\_named\_curve\_alias\_differential`

- Fault: **Named-curve alias resolution differs across backends**
- Category: `backend`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact backend.diff.named\_curve\_aliases = true
- impact = alias resolution differences can bind the same object to different domains across backends

Remediation

- pin an allowed backend matrix and turn backend disagreements into failing regression tests
- document which backend behavior is normative for parsing, validation, and canonicalization

### `curve\_embedding\_degree\_unchecked`

- Fault: **Embedding degree unchecked**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.embedding\_degree\_checked = false
- impact = embedding-degree review helps screen for MOV-style surprises

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_generator\_cofactor\_alignment\_unchecked`

- Fault: **Generator/cofactor alignment unchecked**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.generator\_cofactor\_alignment\_checked = false
- impact = generator and cofactor alignment should be checked so subgroup claims remain coherent

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_hasse\_bound\_unchecked`

- Fault: **Curve order claim not checked against Hasse bound**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.hasse\_bound\_checked = false
- impact = serious ECC review should confirm that claimed orders sit inside the Hasse bound

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_mov\_bound\_unchecked`

- Fault: **MOV bound unchecked**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.mov\_bound\_checked = false
- impact = MOV-style transfer bounds are part of a serious custom-curve audit

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_order\_claim\_source\_missing`

- Fault: **Curve order claim source missing**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.order\_claim\_source\_documented = false
- impact = auditors need a documented source for the claimed curve order, not only the number itself

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_prime\_subgroup\_ratio\_unchecked`

- Fault: **Prime-subgroup ratio unchecked**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.prime\_subgroup\_ratio\_checked = false
- impact = reviewers should know how much of the full group sits inside the intended prime-order subgroup

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `curve\_twist\_trace\_unchecked`

- Fault: **Twist trace not checked**
- Category: `curve`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact curve.twist\_trace\_checked = false
- impact = tracking the twist trace helps validate order and invalid-point assumptions

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

