# FrogECCHunter Report

- **Title:** Invalid preserved pubkey playground
- **Mode:** `parser`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `0`
- **Recovered keys:** `0`

## Severity summary

- `critical`: 0
- `high`: 0
- `medium`: 0
- `low`: 0

## Category summary


## Primary findings

No structural findings were confirmed by the configured checks.
