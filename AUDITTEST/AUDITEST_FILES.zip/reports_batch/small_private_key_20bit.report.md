# FrogECCHunter Report

- **Title:** Small private key range
- **Mode:** `ecdsa`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `4`
- **Recovered keys:** `1`

## Severity summary

- `critical`: 2
- `high`: 1
- `medium`: 1
- `low`: 0

## Category summary

- `ecdsa`: 1
- `keygen`: 2
- `rng`: 1

## Primary findings

### `small\_private\_key\_bsgs`

- Fault: **Small private key range**
- Category: `keygen`
- Severity: `critical`
- Recoverability: `R5\_trivial\_or\_lab\_proven`
- Recovered key: `FLAG{1048573}`

Evidence

- bound\_bits = 20
- recovered\_private\_key\_decimal = 1048573
- flag = FLAG{1048573}
- impact = a private key restricted to a tiny range collapses under bounded discrete-log search

Remediation

- regenerate the long-term key from a full-entropy source and invalidate the weak key immediately
- add key-generation self-tests that reject undersized or patterned private scalars

### `key\_from\_small\_range`

- Fault: **Private key drawn from a tiny range**
- Category: `keygen`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact key.source = small\_range
- impact = tiny private-key ranges collapse under bounded discrete-log search

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `nonce\_not\_rfc6979`

- Fault: **Nonce generation not tied to RFC6979 or equivalent deterministic DRBG**
- Category: `rng`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact nonce.rfc6979 = false
- impact = deterministic nonces anchored in a strong construction reduce a large class of RNG failures

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `high\_s\_malleability\_acceptance`

- Fault: **High-S malleability acceptance**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = 1 supplied signature(s) use high-S form
- impact = accepting high-S values preserves malleability classes unless the protocol normalizes them

Remediation

- normalize signatures to low-S form at signing and verification boundaries
- add replay and duplicate-signature tests to confirm malleability is closed

