# FrogECCHunter Report

- **Title:** Raw family X448 passive-analysis playground
- **Mode:** `parser`
- **Curve:** `X448`
- **Checks:** `348`
- **Findings:** `0`
- **Recovered keys:** `0`

## Severity summary

- `critical`: 0
- `high`: 0
- `medium`: 0
- `low`: 0

## Category summary


## Primary findings

No structural findings were confirmed by the configured checks.
