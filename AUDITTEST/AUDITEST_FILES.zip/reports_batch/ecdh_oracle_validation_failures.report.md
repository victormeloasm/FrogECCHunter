# FrogECCHunter Report

- **Title:** ECDH oracle with validation failures
- **Mode:** `ecdh\_oracle`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `32`
- **Recovered keys:** `0`

## Severity summary

- `critical`: 15
- `high`: 13
- `medium`: 4
- `low`: 0

## Category summary

- `curve`: 3
- `ecdh`: 7
- `oracle`: 3
- `parser`: 1
- `protocol`: 6
- `rng`: 1
- `validation`: 7
- `verification`: 4

## Primary findings

### `cross\_protocol\_scalar\_reuse`

- Fault: **Cross-protocol scalar reuse**
- Category: `protocol`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact cross\_protocol.scalar\_reuse = true
- impact = reusing the same scalar material across signature and key-agreement roles destroys compartmentalization

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `invalid\_curve\_acceptance`

- Fault: **Invalid-curve point acceptance**
- Category: `validation`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.accept\_invalid\_curve\_points = true
- impact = accepting invalid-curve inputs allows carefully chosen small-order points to leak scalar information

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `off\_curve\_public\_key\_acceptance`

- Fault: **Off-curve public key acceptance**
- Category: `validation`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.accept\_off\_curve\_points = true
- impact = off-curve inputs enable invalid-point and twist style attacks against implementations that skip validation

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `oracle\_decrypt\_validity\_leak`

- Fault: **Decrypt-validity oracle exposure**
- Category: `oracle`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.decrypt\_validity = true
- impact = decrypt-validity oracles are often enough to adaptively filter candidate shared secrets

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `oracle\_x\_coordinate\_leak`

- Fault: **Raw x-coordinate oracle exposure**
- Category: `oracle`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.kind = x\_coordinate
- impact = returning raw shared-secret coordinates can hand attackers direct algebraic side information

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `point\_at\_infinity\_acceptance`

- Fault: **Point at infinity acceptance**
- Category: `validation`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.accept\_infinity = true
- impact = accepting the point at infinity can trivialize protocols and collapse key agreement edge cases

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `raw\_shared\_secret\_as\_symmetric\_key`

- Fault: **Raw shared secret used directly as a symmetric key**
- Category: `ecdh`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.use\_raw\_shared\_secret\_as\_key = true
- impact = directly reusing the raw shared secret as an AES or MAC key is brittle and often non-uniform

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `shared\_secret\_without\_kdf`

- Fault: **Shared secret used without a KDF**
- Category: `ecdh`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.use\_kdf = false
- impact = raw shared secrets should be fed through a context-binding KDF before use

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `signature\_nonce\_shared\_with\_ecdh`

- Fault: **ECDSA nonce or scalar reused in ECDH context**
- Category: `protocol`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact cross\_protocol.scalar\_reuse = true
- impact = shared scalar material across ECDSA and ECDH lets one bug poison multiple primitives

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `subgroup\_check\_missing`

- Fault: **Missing subgroup membership check**
- Category: `validation`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.subgroup\_check = false
- impact = missing subgroup checks enable confinement attacks and invalid-point workflows

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `twist\_point\_acceptance`

- Fault: **Twist point acceptance**
- Category: `validation`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.accept\_twist\_points = true
- impact = twist acceptance can hand attackers low-order structure outside the main curve

Remediation

- perform full public-key validation before scalar multiplication
- enforce subgroup membership checks and reject low-order or twist points

### `verifier\_accepts\_mixed\_curve\_domain`

- Fault: **Verifier accepts mixed-curve domain parameters**
- Category: `verification`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.accepts\_mixed\_curve\_domain = true
- impact = accepting mixed domain parameters invalidates the meaning of the public key and generator

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `verifier\_accepts\_out\_of\_range\_r\_or\_s`

- Fault: **Verifier accepts out-of-range r or s**
- Category: `verification`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.accepts\_out\_of\_range\_rs = true
- impact = accepting out-of-range signature components breaks core ECDSA verification assumptions

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `verifier\_accepts\_zero\_r\_or\_s`

- Fault: **Verifier accepts zero-valued r or s**
- Category: `verification`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.accepts\_zero\_rs = true
- impact = accepting zero-valued signature components is catastrophic verifier behavior

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `verifier\_skips\_public\_key\_validation`

- Fault: **Verifier skips public-key validation**
- Category: `verification`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.skips\_public\_key\_validation = true
- impact = verifiers must reject malformed or hostile public keys before doing group operations

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `cofactor\_clearing\_missing`

- Fault: **Missing cofactor clearing**
- Category: `validation`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.cofactor\_clearing = false
- impact = missing cofactor clearing leaves implementations exposed on curves and protocols where cofactors matter

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `curve\_order\_unchecked`

- Fault: **Curve order not validated**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.curve\_order\_checked = false
- impact = unchecked curve order values can break subgroup reasoning and signature validation

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `custom\_rng\_without\_health\_tests`

- Fault: **Custom RNG without health tests**
- Category: `rng`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact rng.custom\_without\_health\_tests = true
- impact = custom RNGs need online health checks and failure handling; otherwise silent degradation is likely

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `generator\_unchecked`

- Fault: **Generator point not validated**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.generator\_checked = false
- impact = an unchecked generator can invalidate every higher-level security assumption on top of the curve

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `hash\_to\_integer\_mismatch`

- Fault: **Hash-to-integer mismatch or truncation confusion**
- Category: `protocol`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact protocol.hash\_to\_int\_mismatch = true
- impact = hash truncation or conversion mismatches break interoperability and can create exploitable verifier disagreements

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `invalid\_public\_key\_encoding\_acceptance`

- Fault: **Invalid public key encoding acceptance**
- Category: `validation`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact validation.accept\_invalid\_public\_key\_encoding = true
- impact = malformed or ambiguously encoded public keys can bypass parser expectations and feed dangerous edge cases

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `no\_ephemeral\_key\_rotation`

- Fault: **No ephemeral key rotation**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact session.rotate\_ephemeral\_keys = false
- impact = without fresh ephemeral keys, many protocols regress toward long-term secret exposure

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `oracle\_timing\_leak\_declared`

- Fault: **Timing side channel declared in oracle path**
- Category: `oracle`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact oracle.timing\_leak = true
- impact = timing differences around parsing, validation, or decryption can act as a side channel

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `shared\_secret\_reuse\_across\_sessions`

- Fault: **Shared secret reused across sessions**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact session.reuse\_shared\_secret = true
- impact = reusing the same derived secret across sessions kills forward secrecy and compounds compromise

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `truncated\_shared\_secret`

- Fault: **Truncated shared secret before KDF or confirmation**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.truncate\_shared\_secret = true
- impact = truncation before KDF or confirmation can throw away entropy and distort interoperability

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `untrusted\_custom\_curve\_parameters`

- Fault: **Untrusted custom curve parameters**
- Category: `curve`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact curve.parameters.trusted\_source = false
- impact = untrusted curve parameters can hide hostile group structure or invalid security assumptions

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `weak\_compressed\_point\_parser`

- Fault: **Weak compressed-point parser**
- Category: `parser`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact parser.weak\_compressed\_point\_parser = true
- impact = weak parsers can accept malformed encodings that bypass security invariants

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `x\_coordinate\_only\_ecdh`

- Fault: **ECDH uses x-coordinate only as the shared secret**
- Category: `ecdh`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact ecdh.use\_x\_coordinate\_only = true
- impact = using only x(P) as a secret without proper validation and KDF handling is fragile and frequently unsafe

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `missing\_domain\_separation\_in\_hashing`

- Fault: **Missing domain separation in hashing**
- Category: `protocol`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact protocol.domain\_separation = false
- impact = reusing the same hash flow across roles without domain separation invites cross-protocol confusion

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `missing\_key\_confirmation`

- Fault: **Missing key confirmation**
- Category: `ecdh`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact protocol.key\_confirmation = false
- impact = without key confirmation, unknown-key-share and oracle-style confusions become easier

Remediation

- run ECDH outputs through a transcript-bound KDF and enforce contributory behavior

### `protocol\_error\_messages\_too\_specific`

- Fault: **Protocol error messages reveal too much detail**
- Category: `protocol`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact oracle.error\_detail = verbose
- impact = overly specific errors improve attacker feedback during adaptive probing

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

### `replay\_protection\_absent`

- Fault: **Replay protection absent**
- Category: `protocol`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact protocol.replay\_protection = false
- impact = missing replay protection can turn valid transcripts into reusable attack material

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

