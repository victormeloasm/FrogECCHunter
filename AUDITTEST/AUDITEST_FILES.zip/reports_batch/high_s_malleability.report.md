# FrogECCHunter Report

- **Title:** High-S ECDSA malleability example
- **Mode:** `ecdsa`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `1`
- **Recovered keys:** `0`

## Severity summary

- `critical`: 0
- `high`: 0
- `medium`: 1
- `low`: 0

## Category summary

- `ecdsa`: 1

## Primary findings

### `high\_s\_malleability\_acceptance`

- Fault: **High-S malleability acceptance**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = 1 supplied signature(s) use high-S form
- impact = accepting high-S values preserves malleability classes unless the protocol normalizes them

Remediation

- normalize signatures to low-S form at signing and verification boundaries
- add replay and duplicate-signature tests to confirm malleability is closed

