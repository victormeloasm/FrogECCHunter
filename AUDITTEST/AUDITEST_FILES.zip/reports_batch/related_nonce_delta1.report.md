# FrogECCHunter Report

- **Title:** Untitled challenge
- **Mode:** `ecdsa`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `2`
- **Recovered keys:** `1`

## Severity summary

- `critical`: 1
- `high`: 0
- `medium`: 1
- `low`: 0

## Category summary

- `ecdsa`: 2

## Primary findings

### `related\_nonce\_delta\_scan`

- Fault: **Linearly related ECDSA nonces**
- Category: `ecdsa`
- Severity: `critical`
- Recoverability: `R5\_trivial\_or\_lab\_proven`
- Recovered key: `FLAG{8234104123542484907464753389986470027747615539807086285208644522913395839540}`

Evidence

- signature\_pair = 0,1
- delta = 1
- recovered\_k1 = 123456789
- recovered\_private\_key\_decimal = 8234104123542484907464753389986470027747615539807086285208644522913395839540
- flag = FLAG{8234104123542484907464753389986470027747615539807086285208644522913395839540}
- impact = linear relations between nonces collapse ECDSA secrecy with just a few signatures

Remediation

- rotate to deterministic RFC6979-style nonces immediately and retire affected signing keys
- search historical signatures for repeated or structured r values and reissue signatures after key rotation

### `high\_s\_malleability\_acceptance`

- Fault: **High-S malleability acceptance**
- Category: `ecdsa`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = 2 supplied signature(s) use high-S form
- impact = accepting high-S values preserves malleability classes unless the protocol normalizes them

Remediation

- normalize signatures to low-S form at signing and verification boundaries
- add replay and duplicate-signature tests to confirm malleability is closed

