# FrogECCHunter Report

- **Title:** Device identifier directly used as ECDSA nonce
- **Mode:** `ecdsa`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `4`
- **Recovered keys:** `1`

## Severity summary

- `critical`: 2
- `high`: 2
- `medium`: 0
- `low`: 0

## Category summary

- `rng`: 4

## Primary findings

### `device\_identifier\_seeded\_nonce\_scan`

- Fault: **Device-identifier seeded nonce generation**
- Category: `rng`
- Severity: `critical`
- Recoverability: `R5\_trivial\_or\_lab\_proven`
- Recovered key: `FLAG{85968058283706962486085}`

Evidence

- generator = device\_id
- recovered\_device\_id = 424242
- recovered\_nonce = 424242
- recovered\_private\_key\_decimal = 85968058283706962486085
- flag = FLAG{85968058283706962486085}
- impact = persistent device identifiers create tiny searchable nonce spaces and can fully expose the signing key

Remediation

- remove device identifiers, serial numbers, and wall-clock inputs from nonce derivation completely
- rotate the signing key because the audit demonstrated a searchable nonce formula

### `device\_identifier\_seeded\_nonce`

- Fault: **Device-identifier seeded nonce generation**
- Category: `rng`
- Severity: `critical`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact rng.generator = device\_id
- impact = device identifiers are low-entropy, persistent inputs and must never drive ECC nonce generation

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `nonce\_not\_rfc6979`

- Fault: **Nonce generation not tied to RFC6979 or equivalent deterministic DRBG**
- Category: `rng`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact nonce.rfc6979 = false
- impact = deterministic nonces anchored in a strong construction reduce a large class of RNG failures

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `nonce\_source\_device\_id`

- Fault: **Device-identifier backed nonce source**
- Category: `rng`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact rng.source = device\_identifier
- impact = persistent device identifiers create tiny enumerable spaces and must never back ECC nonces

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

