# FrogECCHunter Report

- **Title:** PRNG and parser smell bundle
- **Mode:** `ecdh\_oracle`
- **Curve:** `secp256k1`
- **Checks:** `348`
- **Findings:** `4`
- **Recovered keys:** `0`

## Severity summary

- `critical`: 0
- `high`: 2
- `medium`: 2
- `low`: 0

## Category summary

- `parser`: 1
- `protocol`: 1
- `rng`: 1
- `verification`: 1

## Primary findings

### `nonce\_source\_pcg32`

- Fault: **PCG32-based nonce generation**
- Category: `rng`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact rng.source = pcg32
- impact = PCG32 is statistically decent for general use but is not a cryptographic nonce source for ECC signatures

Remediation

- replace ad-hoc nonce generation with RFC6979 or a vetted cryptographic DRBG
- add regression tests that fail on repeated, biased, or structured nonces

### `signature\_scalar\_range\_check\_missing`

- Fault: **Signature scalar range check missing**
- Category: `verification`
- Severity: `high`
- Recoverability: `R2\_structural\_high\_risk`

Evidence

- evidence = fact verification.scalar\_range\_check = false
- impact = missing scalar range checks lets malformed signature values pass deeper into verification code

Remediation

- enforce strict scalar range checks and bind each verification to one exact domain and key

### `parser\_accepts\_trailing\_garbage`

- Fault: **Parser accepts trailing garbage after key material**
- Category: `parser`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact parser.accept\_trailing\_garbage = true
- impact = accepting trailing garbage after encoded points or scalars can create ambiguous parsing states and security bypasses

Remediation

- accept only canonical encodings and reject malformed, duplicated, or trailing-garbage inputs

### `signature\_context\_reuse`

- Fault: **Signature context reuse across domains**
- Category: `protocol`
- Severity: `medium`
- Recoverability: `R1\_structural\_risk`

Evidence

- evidence = fact protocol.signature\_context\_reuse = true
- impact = reusing the same signature context across protocol roles undermines domain separation

Remediation

- tighten validation, add a regression test for the supplied evidence, and document the safer invariant

